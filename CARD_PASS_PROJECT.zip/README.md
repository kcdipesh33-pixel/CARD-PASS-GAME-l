# CARD PASS – Flutter starter

This is a starter Flutter project, not a finished game.

## Included
- Flutter app home screen
- Basic local WebSocket host/join lobby on port 8080
- Host control is separate from players
- Player list capped at 8

## Important
- Connect every phone to the same Wi-Fi/hotspot.
- Start the host server on the host phone and share its displayed IP.
- The host IP varies by Android phone/hotspot; `192.168.43.1` is only an example.
- This starter does NOT yet implement the actual card rules, turn logic, one-hand enforcement, QR scan/join, owner PIN, or complete gameplay.

## Build an APK
The GitHub Actions workflow in `.github/workflows/build-apk.yml` creates a temporary Android platform project, builds a release APK, and stores it as an Actions artifact.
