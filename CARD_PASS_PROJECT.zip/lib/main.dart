import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';

void main() => runApp(const CardPassApp());

class CardPassApp extends StatelessWidget {
  const CardPassApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CARD PASS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5B4BDB)),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  HttpServer? _server;
  final List<String> _players = [];
  final List<WebSocket> _clients = [];
  final TextEditingController _name = TextEditingController();
  final TextEditingController _ip = TextEditingController();
  String _status = 'Not connected';
  String _hostAddress = '';
  bool _isHost = false;
  bool _gameStarted = false;
  WebSocket? _connection;

  Future<String> _findLocalAddress() async {
    try {
      final interfaces = await NetworkInterface.list(
        includeLoopback: false,
        type: InternetAddressType.IPv4,
      );
      for (final interface in interfaces) {
        for (final address in interface.addresses) {
          if (!address.isLoopback) return address.address;
        }
      }
    } catch (_) {}
    return 'Check your hotspot IP';
  }

  Future<void> _startHost() async {
    try {
      _server = await HttpServer.bind(InternetAddress.anyIPv4, 8080);
      _hostAddress = await _findLocalAddress();
      _isHost = true;
      _status = 'Host is running';
      _server!.listen((request) async {
        if (WebSocketTransformer.isUpgradeRequest(request)) {
          final socket = await WebSocketTransformer.upgrade(request);
          _clients.add(socket);
          socket.listen((message) {
            try {
              final data = jsonDecode(message as String) as Map<String, dynamic>;
              if (data['type'] == 'join') {
                final player = (data['name'] ?? 'Player').toString().trim();
                if (player.isNotEmpty && _players.length < 8 && !_gameStarted) {
                  _players.add(player);
                  _broadcast({'type': 'players', 'players': _players});
                }
              }
            } catch (_) {}
          }, onDone: () {
            _clients.remove(socket);
          });
        } else {
          request.response
            ..statusCode = HttpStatus.ok
            ..write('CARD PASS local game server')
            ..close();
        }
      });
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) setState(() => _status = 'Could not start host: $e');
    }
  }

  void _broadcast(Map<String, dynamic> data) {
    final encoded = jsonEncode(data);
    for (final client in List<WebSocket>.from(_clients)) {
      if (client.readyState == WebSocket.open) {
        client.add(encoded);
      }
    }
  }

  Future<void> _joinGame() async {
    final name = _name.text.trim();
    final ip = _ip.text.trim();
    if (name.isEmpty || ip.isEmpty) {
      setState(() => _status = 'Enter your name and host IP address.');
      return;
    }
    try {
      _connection = await WebSocket.connect('ws://$ip:8080');
      _connection!.listen((message) {
        try {
          final data = jsonDecode(message as String) as Map<String, dynamic>;
          if (data['type'] == 'players') {
            setState(() {
              _players
                ..clear()
                ..addAll((data['players'] as List).map((e) => e.toString()));
            });
          } else if (data['type'] == 'start') {
            setState(() => _gameStarted = true);
          }
        } catch (_) {}
      }, onDone: () => setState(() => _status = 'Disconnected'));
      _connection!.add(jsonEncode({'type': 'join', 'name': name}));
      setState(() => _status = 'Connected to host');
    } catch (e) {
      setState(() => _status = 'Could not connect. Check same hotspot and IP.');
    }
  }

  void _startGame() {
    if (_players.isEmpty) {
      setState(() => _status = 'At least one player must join first.');
      return;
    }
    _gameStarted = true;
    _broadcast({'type': 'start'});
    setState(() => _status = 'Game started');
  }

  @override
  void dispose() {
    _server?.close(force: true);
    _connection?.close();
    for (final client in _clients) {
      client.close();
    }
    _name.dispose();
    _ip.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CARD PASS – Play, Pass, Win')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.style, size: 72),
          const SizedBox(height: 8),
          const Text('Offline multiplayer game',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(_status, textAlign: TextAlign.center),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('HOST CONTROL', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Host phone is the controller, not a player. Start the phone hotspot first.'),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _server == null ? _startHost : null,
                  icon: const Icon(Icons.wifi),
                  label: const Text('Start host server'),
                ),
                if (_hostAddress.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  SelectableText('Host IP: $_hostAddress\nPort: 8080'),
                ],
                const SizedBox(height: 8),
                FilledButton(
                  onPressed: _isHost && !_gameStarted ? _startGame : null,
                  child: const Text('Start game'),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('JOIN GAME', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(controller: _name, decoration: const InputDecoration(labelText: 'Player name')),
                TextField(
                  controller: _ip,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Host IP address (example: 192.168.43.1)'),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _joinGame,
                  icon: const Icon(Icons.login),
                  label: const Text('Join'),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Players (${_players.length}/8)', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                if (_players.isEmpty) const Text('No players joined yet.'),
                for (var i = 0; i < _players.length; i++)
                  ListTile(
                    dense: true,
                    leading: CircleAvatar(child: Text('${i + 1}')),
                    title: Text(_players[i]),
                  ),
                if (_gameStarted)
                  const Text('Game session started. Add the exact card rules and turn sequence before gameplay is complete.',
                      style: TextStyle(fontWeight: FontWeight.w600)),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Development starter: this project provides a basic local WebSocket lobby. The actual card rules, one-hand turn mechanics, QR joining, owner PIN settings, and full game screen still need to be implemented.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
